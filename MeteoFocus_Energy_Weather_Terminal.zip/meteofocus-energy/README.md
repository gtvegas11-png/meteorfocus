# MeteoFocus Energy Weather Terminal

A runnable prototype with a browser dashboard and a small Node.js backend proxy for NOAA/National Weather Service data.

## What is included

- Configurable example hubs for ERCOT, PJM, MISO, SPP, CAISO, NYISO, ISO-NE, and the Midwest Crop Belt.
- NWS hourly and daily forecasts, forecast-grid fields when returned by the NWS API, active alerts by point, and latest observation attempts from nearby reporting stations.
- Preliminary hourly HDD/CDD indicators using a 65°F base.
- Weather condition metrics, precipitation probability, wind, station observation timestamp, and a radar display link.
- Browser-local forecast snapshot ledger.
- Source-health/error indicators and a model-feed catalog that explicitly marks raw GFS/GEFS/HRRR ingestion as not yet implemented.
- Five-minute backend response cache (shorter for observations and alerts); the UI refreshes every ten minutes.

## Run locally

Requires Node.js 20 or newer. No npm packages are required.

1. Unzip the project.
2. In a terminal, change into the `meteofocus-energy` directory.
3. Configure an identifying User-Agent for the NWS API. Use contact information you control:
   - Windows PowerShell: `$env:NWS_USER_AGENT="MeteoFocusEnergy/1.0 (contact: you@example.com)"`
   - macOS/Linux: `export NWS_USER_AGENT="MeteoFocusEnergy/1.0 (contact: you@example.com)"`
4. Start it: `node server.js`
5. Open `http://localhost:8080`.

Opening `public/index.html` directly as a file will not work because it expects the local `/api/...` backend.

## Data and methodology caveats

- The NWS API provides forecasts, grid forecasts, stations, and alerts. Availability and latency differ by field/station. Missing values are displayed as unavailable, not fabricated.
- The station lookup tries a few nearby stations and uses the first with a timestamp and a temperature. Production systems should add explicit station allowlists, quality checks, age limits, provenance and per-field fallback policies.
- The degree-day method is a simple hourly approximation over the first 24 forecast periods, with base 65°F. It is not an ISO/RTO load forecast and should be validated against the methodology your team intends to use.
- Forecast snapshots are saved in the current browser only. A production revision ledger needs server-side persistent storage, model run identifiers, valid-time alignment, and retention policies.
- The GFS/GEFS/HRRR catalog is informational. Raw model-grid download, GRIB2 decoding, spatial aggregation, ensemble statistics, and model-to-model comparisons are NOT implemented by this starter. NOAA/NCEP NOMADS is linked as the source. These should be added as a separate ingestion worker (e.g. scheduled jobs + GRIB2 decoder + database/object storage) rather than being misrepresented as live.
- The radar panel uses the NWS radar website; it is not an embedded raw radar-data feed. The NWS API documentation notes radar display data is served separately.
- Before public deployment: add authentication if needed, server-side request throttling, structured logging/monitoring, HTTPS, deployment-specific CORS/security headers, durable database storage, backups, uptime alerts, and data-quality tests. Validate all metrics before operational use.

## Useful official documentation

- NWS API: https://www.weather.gov/documentation/services-web-api
- NOAA/NCEP NOMADS: https://nomads.ncep.noaa.gov/
- NWS alerts API: https://www.weather.gov/documentation/services-web-alerts
