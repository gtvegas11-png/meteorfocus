/**
 * MeteoFocus Energy Weather API
 * Node.js 20+, zero npm dependencies.
 * NOAA/NWS endpoints are public. Identify your application with a User-Agent
 * before production deployment and review the NWS API usage guidance.
 */
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { URL } = require("node:url");

const PORT = Number(process.env.PORT || 8080);
const PUBLIC_DIR = path.join(__dirname, "public");
const NWS = "https://api.weather.gov";
const USER_AGENT = process.env.NWS_USER_AGENT || "MeteoFocusEnergy/1.0 (configure-contact-before-production)";
const cache = new Map();
const TTL_MS = 5 * 60 * 1000;

const REGIONS = {
  ERCOT_DALLAS: { id:"ERCOT_DALLAS", name:"ERCOT · North Texas", lat:32.7767, lon:-96.7970, state:"TX", market:"ERCOT", zone:"Texas" },
  ERCOT_HOUSTON: { id:"ERCOT_HOUSTON", name:"ERCOT · Houston", lat:29.7604, lon:-95.3698, state:"TX", market:"ERCOT", zone:"Texas" },
  ERCOT_WEST: { id:"ERCOT_WEST", name:"ERCOT · West Texas", lat:31.9973, lon:-102.0779, state:"TX", market:"ERCOT", zone:"Texas" },
  PJM_PITTSBURGH: { id:"PJM_PITTSBURGH", name:"PJM · Pittsburgh", lat:40.4406, lon:-79.9959, state:"PA", market:"PJM", zone:"Mid-Atlantic" },
  PJM_PHILADELPHIA: { id:"PJM_PHILADELPHIA", name:"PJM · Philadelphia", lat:39.9526, lon:-75.1652, state:"PA", market:"PJM", zone:"Mid-Atlantic" },
  MISO_CHICAGO: { id:"MISO_CHICAGO", name:"MISO · Chicago", lat:41.8781, lon:-87.6298, state:"IL", market:"MISO", zone:"Midwest" },
  MISO_MINNEAPOLIS: { id:"MISO_MINNEAPOLIS", name:"MISO · Minneapolis", lat:44.9778, lon:-93.2650, state:"MN", market:"MISO", zone:"Midwest" },
  SPP_OKLAHOMA: { id:"SPP_OKLAHOMA", name:"SPP · Oklahoma City", lat:35.4676, lon:-97.5164, state:"OK", market:"SPP", zone:"Plains" },
  CAISO_BAKERSFIELD: { id:"CAISO_BAKERSFIELD", name:"CAISO · Bakersfield", lat:35.3733, lon:-119.0187, state:"CA", market:"CAISO", zone:"California" },
  NYISO_ALBANY: { id:"NYISO_ALBANY", name:"NYISO · Albany", lat:42.6526, lon:-73.7562, state:"NY", market:"NYISO", zone:"Northeast" },
  ISO_NE_BOSTON: { id:"ISO_NE_BOSTON", name:"ISO-NE · Boston", lat:42.3601, lon:-71.0589, state:"MA", market:"ISO-NE", zone:"New England" },
  MIDWEST_DES_MOINES: { id:"MIDWEST_DES_MOINES", name:"Midwest Crop Belt · Des Moines", lat:41.5868, lon:-93.6250, state:"IA", market:"Agriculture", zone:"Midwest" }
};

async function fetchJson(url, ttl = TTL_MS) {
  const cached = cache.get(url);
  if (cached && Date.now() - cached.at < ttl) return cached.value;
  const response = await fetch(url, {
    headers: { "Accept":"application/geo+json, application/ld+json", "User-Agent":USER_AGENT },
    signal: AbortSignal.timeout(15000)
  });
  if (!response.ok) {
    const err = new Error(`Upstream request failed (${response.status})`);
    err.status = response.status;
    throw err;
  }
  const value = await response.json();
  cache.set(url, { at:Date.now(), value });
  return value;
}
const val = p => p && typeof p.value === "number" ? p.value : null;
const cToF = c => c == null ? null : c * 9/5 + 32;
const mpsToMph = v => v == null ? null : v * 2.236936;
const paToInHg = v => v == null ? null : v / 3386.389;
const cToIn = v => v == null ? null : v / 25.4;

function observationNormalize(feature) {
  const p = feature?.properties || {};
  const tempC = val(p.temperature), dewC = val(p.dewpoint);
  return {
    stationId: p.station?.split("/").filter(Boolean).pop() || null,
    stationName: p.stationName || null,
    timestamp: p.timestamp || null,
    textDescription: p.textDescription || "Not reported",
    temperatureF: cToF(tempC),
    dewpointF: cToF(dewC),
    relativeHumidityPct: val(p.relativeHumidity),
    windDirectionDeg: val(p.windDirection),
    windSpeedMph: mpsToMph(val(p.windSpeed)),
    windGustMph: mpsToMph(val(p.windGust)),
    pressureInHg: paToInHg(val(p.barometricPressure)),
    visibilityMiles: val(p.visibility) == null ? null : val(p.visibility) / 1609.344,
    precipitationLastHourIn: cToIn(val(p.precipitationLastHour)),
    rawQuality: "As reported by NWS station endpoint"
  };
}
function degreeDays(hourlyPeriods) {
  let hdd = 0, cdd = 0, count = 0;
  for (const p of hourlyPeriods) {
    if (typeof p.temperature !== "number") continue;
    const f = p.temperatureUnit === "C" ? cToF(p.temperature) : p.temperature;
    hdd += Math.max(0, 65 - f) / 24;
    cdd += Math.max(0, f - 65) / 24;
    count++;
  }
  return { hdd: count ? hdd : null, cdd: count ? cdd : null, hoursUsed: count, method:"Hourly mean of max(0, 65°F − T) / 24 and max(0, T − 65°F) / 24; partial day if fewer than 24 valid periods" };
}
function normalizePeriod(p) {
  return {
    startTime:p.startTime, endTime:p.endTime, isDaytime:p.isDaytime,
    temperatureF:p.temperatureUnit === "C" ? cToF(p.temperature) : p.temperature,
    shortForecast:p.shortForecast || "", detailedForecast:p.detailedForecast || "",
    probabilityOfPrecipitationPct:p.probabilityOfPrecipitation?.value ?? null,
    relativeHumidityPct:p.relativeHumidity?.value ?? null,
    windSpeed:p.windSpeed || null, windDirection:p.windDirection || null,
    dewpointF:p.dewpoint?.value == null ? null : (p.dewpoint.unitCode?.endsWith("degC") ? cToF(p.dewpoint.value) : p.dewpoint.value),
    icon:p.icon || null
  };
}
async function regionData(region) {
  const point = await fetchJson(`${NWS}/points/${region.lat},${region.lon}`, 24*60*60*1000);
  const pp = point.properties || {};
  const [hourly, daily, grid, stations, alertData] = await Promise.all([
    fetchJson(pp.forecastHourly),
    fetchJson(pp.forecast),
    pp.forecastGridData ? fetchJson(pp.forecastGridData) : Promise.resolve(null),
    fetchJson(pp.observationStations),
    fetchJson(`${NWS}/alerts/active?point=${region.lat},${region.lon}`, 60*1000)
  ]);
  const stationFeatures = stations.features || [];
  let observation = null;
  let selectedStation = null;
  // Try the closest few stations because not every station has a fresh observation.
  for (const feature of stationFeatures.slice(0, 4)) {
    const stationUrl = feature.id || feature["@id"];
    if (!stationUrl) continue;
    try {
      const obs = await fetchJson(`${stationUrl.replace(/\/$/,"")}/observations/latest`, 2*60*1000);
      if (obs.properties?.timestamp && obs.properties?.temperature?.value != null) {
        observation = observationNormalize(obs);
        selectedStation = feature.properties || {};
        break;
      }
    } catch (_) {}
  }
  const hourlyPeriods = (hourly.properties?.periods || []).map(normalizePeriod);
  const dailyPeriods = (daily.properties?.periods || []).map(normalizePeriod);
  const dd = degreeDays(hourlyPeriods.slice(0,24).map(p => ({
    temperature:p.temperatureF, temperatureUnit:"F"
  })));
  const gp = grid?.properties || {};
  const series = {};
  for (const name of ["temperature","dewpoint","relativeHumidity","windSpeed","windGust","skyCover","probabilityOfPrecipitation","quantitativePrecipitation","iceAccumulation","snowfallAmount"]) {
    const item = gp[name];
    if (item) series[name] = { uom:item.uom, values:item.values };
  }
  const alerts = (alertData.features || []).map(f => {
    const p = f.properties || {};
    return {
      id:p.id || f.id || null, event:p.event || "Weather alert", headline:p.headline || "",
      severity:p.severity || "Unknown", urgency:p.urgency || "Unknown", certainty:p.certainty || "Unknown",
      status:p.status || "", areaDesc:p.areaDesc || "", onset:p.onset || p.effective || null,
      expires:p.expires || null, instruction:p.instruction || "", description:p.description || "",
      senderName:p.senderName || "", web:p.web || null
    };
  });
  return {
    region, source:"NOAA/National Weather Service API", fetchedAt:new Date().toISOString(),
    point:{ forecastOffice:pp.cwa || null, gridId:pp.gridId || null, gridX:pp.gridX ?? null, gridY:pp.gridY ?? null },
    station:{ id:selectedStation?.stationIdentifier || observation?.stationId || null, name:selectedStation?.name || observation?.stationName || null, distanceMeters:selectedStation?.distance?.value ?? null, observation },
    forecast:{ updatedAt:hourly.properties?.updateTime || null, periods:hourlyPeriods, daily:dailyPeriods, degreeDays:dd },
    grid:{ validTime:gp.updateTime || null, series },
    alerts
  };
}
function send(res, status, data) {
  res.writeHead(status, { "Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store", "Access-Control-Allow-Origin":"*", "X-Content-Type-Options":"nosniff" });
  res.end(JSON.stringify(data));
}
function safeError(err) {
  return { error:err.message || "Unknown error", status:err.status || 502, hint:"Check the server logs and NOAA/NWS upstream status. Missing fields can be normal for some stations." };
}
const mime = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".json":"application/json; charset=utf-8", ".svg":"image/svg+xml" };

const server = http.createServer(async (req,res) => {
  const base = `http://${req.headers.host || "localhost"}`;
  const url = new URL(req.url, base);
  if (req.method === "OPTIONS") { res.writeHead(204, {"Access-Control-Allow-Origin":"*", "Access-Control-Allow-Methods":"GET,OPTIONS", "Access-Control-Allow-Headers":"Content-Type"}); return res.end(); }
  if (url.pathname === "/api/health") return send(res,200,{ok:true,service:"MeteoFocus Energy Weather API",now:new Date().toISOString(),upstream:"NOAA/NWS",cacheEntries:cache.size});
  if (url.pathname === "/api/regions") return send(res,200,{regions:Object.values(REGIONS)});
  if (url.pathname === "/api/region") {
    const id = url.searchParams.get("id");
    const region = REGIONS[id];
    if (!region) return send(res,400,{error:"Unknown region id",available:Object.keys(REGIONS)});
    try { return send(res,200,await regionData(region)); }
    catch(err) { console.error("Region request failed",id,err); return send(res,err.status || 502,safeError(err)); }
  }
  if (url.pathname === "/api/alerts") {
    try {
      const id = url.searchParams.get("id");
      if (id) {
        const region = REGIONS[id];
        if (!region) return send(res,400,{error:"Unknown region id"});
        const data = await fetchJson(`${NWS}/alerts/active?point=${region.lat},${region.lon}`,60*1000);
        return send(res,200,{source:"NOAA/NWS",region:region.id,alerts:(data.features||[]).map(f=>f.properties)});
      }
      const state = (url.searchParams.get("state") || "TX").toUpperCase();
      if (!/^[A-Z]{2}$/.test(state)) return send(res,400,{error:"state must be a two-letter state code"});
      const data = await fetchJson(`${NWS}/alerts/active?area=${state}`,60*1000);
      return send(res,200,{source:"NOAA/NWS",state,alerts:(data.features||[]).map(f=>f.properties)});
    } catch(err) { return send(res,err.status || 502,safeError(err)); }
  }
  if (url.pathname === "/api/models") {
    return send(res,200,{
      note:"Catalog only. Raw NOAA model grids are not ingested by this starter service.",
      modelFeeds:[
        {id:"GFS",name:"Global Forecast System",status:"external-ingestion-required",source:"NOAA/NCEP NOMADS",url:"https://nomads.ncep.noaa.gov/"},
        {id:"GEFS",name:"Global Ensemble Forecast System",status:"external-ingestion-required",source:"NOAA/NCEP NOMADS",url:"https://nomads.ncep.noaa.gov/"},
        {id:"HRRR",name:"High-Resolution Rapid Refresh",status:"external-ingestion-required",source:"NOAA/NCEP NOMADS",url:"https://nomads.ncep.noaa.gov/"},
        {id:"NWS_GRID",name:"NWS forecast grid",status:"live",source:"NOAA/NWS API",url:"https://api.weather.gov/"}
      ]
    });
  }
  const filePath = path.normalize(path.join(PUBLIC_DIR, decodeURIComponent(url.pathname === "/" ? "index.html" : url.pathname)));
  if (!filePath.startsWith(PUBLIC_DIR)) return send(res,403,{error:"Forbidden"});
  fs.readFile(filePath,(err,content)=>{
    if(err) return send(res,404,{error:"Not found"});
    res.writeHead(200,{"Content-Type":mime[path.extname(filePath)] || "application/octet-stream","X-Content-Type-Options":"nosniff"});
    res.end(content);
  });
});
server.listen(PORT,()=>console.log(`MeteoFocus running at http://localhost:${PORT}`));
